=== Swipecart ===
Contributors: manthankanani
Tags: Android App,Mobile App,android,ios,mobile,app for wordpress
Donate link: 
Requires at least: 4.9
Tested up to: 5.9
Stable tag: 1.0.0
Requires PHP: 7.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Launch a world-class mobile app for your brand. Please, Don't Remove this plugin , This will affect your Swipecart App.

== Description ==

Swipecart is the mobile app builder which is highly preferred by small and big e-commerce organizations looking to boost mobile conversions, increase the fold of repeat orders, and increase revenue.

= Set up and integrate your site with Swipecart mobile app. =

Once the store is effortlessly synchronized you can start to increase your sales and give your customers a personalized shopping experience with a mobile app.

This plugin isn't an app maker in and of itself; instead, it aids in the integration of your app with ecommerce sites just install and activate. 


A few notes about the Activation of the Swipecart:

When it comes to transitioning from WooCommerce to an Android or iOS app, Swipecart is just the ideal choice for many organizations. Developing a mobile app often needs extensive programming and technical skills. You can simply transform your e-commerce business into a mobile app using Swipecart no-code mobile app builder without any technical knowledge.

Swipecart enables you to get an eCommerce app that is perfectly integrated to your WooCommerce store. Here is how to install and activate Swipecart and generate Auth token and Secret token for Woocommerce. Simply follow the steps given below:

* Go to Woocommece settings and Click on the Integrations button.
* You will see Swipecart integrations and there is your Auth Token and Auth Secret for Woocommerce.

== Frequently Asked Questions ==

= Is it possible to change my Auth token and key? =

Yes, you can change them, but you'll have to deactivate, uninstall, and then reinstall the Swipecart plugin in order to get a new Auth token and Key.

= Is it possible to add more sophisticated features? =

Yes, you certainly can. We recommend you to check out the web link given below and purchase our enterprise plan to do so. This plan is perfect if you wish to integrate custom features. [Swipecart Pricing] (https://rentechdigital.com/swipecart/pricing)

= Is this Secure to use? =

Yes, We ensure full security for our customers. Our API's are secure and end-to-end encrypted. We refer our API's through our private broker, who doesn't have any personal third-party access to anyone.

= Can I run without Woocommerce? =

No, It's our main dependency so you can not run the plugin without Woocommerce. 

= Is this compatible with all WordPress versions? =

No, we recommend you to use this plugin on wordpress 5.0+. It works just perfect!

= Are these APIs directly accessible? =

No, The API Key and Access Token are both 64-bit secure, and you'll need both Key and Token to run all the APIs.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Screenshots are stored in the /assets directory.
2. This is the second screen shot

== Changelog ==

= 1.0.0 =
* New: Initial release.
* New: Added Woocommerce dependancy.
* New: Added 64-bit Access Security.

== Upgrade Notice ==

= 1.0.0 =
* Intial Release 

